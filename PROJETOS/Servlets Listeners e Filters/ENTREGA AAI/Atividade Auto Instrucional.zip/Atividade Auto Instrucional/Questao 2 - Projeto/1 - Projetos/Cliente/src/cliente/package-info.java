@javax.xml.bind.annotation.XmlSchema(namespace = "http://webservice/")
package cliente;
